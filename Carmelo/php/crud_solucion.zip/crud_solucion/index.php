<?php
include("header.php");
echo "<h1>Ejercicio CRUD completo</h1>";

echo phpinfo();
include("footer.php");
?>


