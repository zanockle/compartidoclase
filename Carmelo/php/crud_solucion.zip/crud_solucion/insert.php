<?php
include("header.php");
echo "<h1>Insert - Añadir registros</h1>";


include("footer.php");
?>
