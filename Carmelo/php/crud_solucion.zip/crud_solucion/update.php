<?php
include("header.php");
echo "<h1>Update - Actualizar registros</h1>";


include("footer.php");
?>
