<?php
include("header.php");
echo "<h1>Select - Mostrar registros</h1>";


include("footer.php");
?>
