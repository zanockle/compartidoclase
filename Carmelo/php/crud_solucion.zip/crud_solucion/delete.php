<?php
include("header.php");
echo "<h1>Delete - Eliminar registros</h1>";


include("footer.php");
?>
