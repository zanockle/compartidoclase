#!/bin/bash
if [ 2 -gt 1 ]
then
   echo "2 es mayor que 1"
else
   echo "2 no es mayor que 1"
fi;