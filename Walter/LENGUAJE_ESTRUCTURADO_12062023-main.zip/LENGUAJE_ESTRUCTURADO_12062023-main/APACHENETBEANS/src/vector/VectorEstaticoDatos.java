package vector;

public class VectorEstaticoDatos {

    public static void main(String[] args) {
        Metodos.cabecera();
        Metodos.cuerpo();
    }
}
