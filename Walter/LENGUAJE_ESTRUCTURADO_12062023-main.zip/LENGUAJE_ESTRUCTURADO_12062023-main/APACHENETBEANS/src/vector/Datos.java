package vector;

public class Datos {

    static int[] edades = {17, 20, 21, 24, 25, 28};
    static double[] estaturas = {1.72, 1.69, 1.80, 1.45, 1.48, 1.60};
    //float[] estaturas = {1.72f,1.69f,1.80f,1.45f,1.48f,1.60f};
    static String[] nombres = {"Luis", "Miguel",
        "Carlos", "Carmen",
        "María", "Arturo"};
    static char[] sexo = {'H', 'H', 'H', 'M', 'M', 'H'};
    static boolean[] esCasado = {true, false, true, false, true, true};

}
