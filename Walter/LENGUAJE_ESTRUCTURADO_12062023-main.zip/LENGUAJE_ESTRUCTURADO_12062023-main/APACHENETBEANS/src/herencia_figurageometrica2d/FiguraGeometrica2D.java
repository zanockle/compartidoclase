package herencia_figurageometrica2d;

public class FiguraGeometrica2D {
    
    public double area() {
        return 0.0;
    }
    
    public double perimetro() {
        return 0.0;
    }
    
    public String soy() {
        return "";
    }
    
    public void nada() {
        System.out.println("SOY NADA");//Cuadrado, Circulo
    }
    
    
    public String numeroDimension() {
        return "Dos dimensiones";
    }
    
}
