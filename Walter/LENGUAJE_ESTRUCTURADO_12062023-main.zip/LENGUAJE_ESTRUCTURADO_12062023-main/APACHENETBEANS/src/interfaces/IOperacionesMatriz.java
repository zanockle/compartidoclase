package interfaces;

public interface IOperacionesMatriz {
    
    
   public void ejercicio1();
}
