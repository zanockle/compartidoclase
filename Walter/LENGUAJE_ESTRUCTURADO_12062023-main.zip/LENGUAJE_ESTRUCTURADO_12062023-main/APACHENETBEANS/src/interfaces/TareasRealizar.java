package interfaces;


public interface TareasRealizar {
    public int sumar(double a, double b);//FIRMA DEL METODO = PROTOTIPO
    public int restar(int a, int b);
    public int muntiplicacion(int a, int b);
}
