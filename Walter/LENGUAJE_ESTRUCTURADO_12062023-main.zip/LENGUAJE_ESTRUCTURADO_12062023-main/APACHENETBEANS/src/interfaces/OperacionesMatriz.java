package interfaces;

public interface OperacionesMatriz {
    
    public void convierteCeroLosParesy1Impares(int[][] matrizEnteros);
    //public  convierteCeroLosParesy1Impares(int[][] matrizEnteros);
}
