package interfaces;

public interface IUtil {
    
    public void imprimirMatrizEntero(int[][] matriz);
}
