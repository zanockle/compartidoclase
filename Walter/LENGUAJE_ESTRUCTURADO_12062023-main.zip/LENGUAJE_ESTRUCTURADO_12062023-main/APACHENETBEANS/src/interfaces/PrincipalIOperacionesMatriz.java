package interfaces;

public class PrincipalIOperacionesMatriz {

    public static void main(String[] args) {

         ResolverIMatriz rm = new ResolverIMatriz();
         rm.ejercicio1();

    }

}
