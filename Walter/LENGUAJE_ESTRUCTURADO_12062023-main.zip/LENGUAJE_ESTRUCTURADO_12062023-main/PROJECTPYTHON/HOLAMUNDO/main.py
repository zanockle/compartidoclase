print('Hola Mundo')

print('"Hola Mundo"')

print("'Hola Mundo'")