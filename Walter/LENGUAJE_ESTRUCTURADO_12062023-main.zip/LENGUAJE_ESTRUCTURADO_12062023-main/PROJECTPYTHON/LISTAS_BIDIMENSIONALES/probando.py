
import random

caracteres = "ABCDEFGHIJKLMNÑOPQRSTUVWXYZ"  # Definimos los caracteres disponibles

caracter = random.choice(caracteres)  # Obtenemos un carácter aleatorio

print(caracter)
