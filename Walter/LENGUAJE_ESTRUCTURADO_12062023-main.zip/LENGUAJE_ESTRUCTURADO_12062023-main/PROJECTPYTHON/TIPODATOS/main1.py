import os

os.system('cls')

print("TIPO DINAMICO")
print("-------------")

x1 = 23 #int
x1 = 2.3 #float
x1 = "Hola Mundo" #str
x1 = False #bool

print("X1: ", x1)

print("TIPO ENTERO")
print("-----------")

x2 = 23         #Decimal
x2 = 0b10111    #Binario
x2 = 0o27       #Octal
x2 = 0x17       #Hexadecimal

print("X2: ", x2)

print('TIPO PUNTO FLOTANTE')
print('-------------------')

x3 = 0.0000012345 #Notación Normal
x3 = 1.2345e-6    #Notación Científica

print('X3: ', x3)

print('TIPO CADENA')
print('-----------')

x4 = "Como estan todos"

print("X4: ", x4)

print('TIPO LOGICO')
print('-----------')

x5 = True
x5 = False

print("X5: ", x5)

print('TIPO CARACTER')
print('-------------')

x6 = b'?'
x6 = b'A'

print("X6: ", x6)

os.system('pause')






