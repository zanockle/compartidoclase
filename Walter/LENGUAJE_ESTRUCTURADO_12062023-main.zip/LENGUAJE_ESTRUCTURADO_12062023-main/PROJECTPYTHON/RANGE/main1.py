

x = range(0,5,1) 
