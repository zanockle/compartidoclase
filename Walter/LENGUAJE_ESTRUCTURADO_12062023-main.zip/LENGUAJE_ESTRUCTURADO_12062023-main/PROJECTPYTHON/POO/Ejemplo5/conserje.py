from empleado import Empleado

class Conserje(Empleado):
      


      def apoyar():
          print('Trasladar documentos entre departamentos')
      
