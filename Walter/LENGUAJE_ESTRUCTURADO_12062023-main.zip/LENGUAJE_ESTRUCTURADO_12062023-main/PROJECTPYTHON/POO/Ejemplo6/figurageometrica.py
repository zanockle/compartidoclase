
class FiguraGeometrica:

      def perimetro(self):
          pass
      
      def area(self):
          pass
      
      def soy(self):
          pass