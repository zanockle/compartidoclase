import os
from misclases import ClaseHijo

os.system('cls')
objeto = ClaseHijo()

objeto.metodo1_1()
objeto.metodo2_1()