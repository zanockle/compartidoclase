# SERIE NATURAL N: 1, 2, 3, 4, 5

import os

os.system('cls')
n = int(input('Ingrese N? '))

i = 1
while i <= n:
    print(i)
    i = i + 1 # i += 1

i=1
while i <= n:
    print(i, end="  ")
    i += 1



