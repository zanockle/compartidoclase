import os

os.system('cls')

# PONTENCIA

x = 5
e = 3
potencia = x ** e
print("Potencia: ", potencia)

# RAIZ CUADRADA

x = 2
e = 0.5
raizcuadrada = x ** e
print('Raiz Cuadrada: ', raizcuadrada)

# REDONDEAR A DOS DICIMALES

print('Raiz Cuadrada: ', round(raizcuadrada,2))
