import os

if __name__ == "__main__":
   os.system('cls')
   print('LISTA DE TAMAÑO FIJO')
   print('--------------------')
   vector1 = [0]*2
   vector1[0] = 5
   vector1[1] = 6
   print(vector1)
   print('LISTA DE TAMAÑO VARIABLE')
   print('------------------------')
   vector2 = []
   vector2.append(5)
   vector2.append(6)
   vector2.append(7)
   print(vector2)
