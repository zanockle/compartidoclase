import math

def getPerimetro(radio):
    return 2*math.pi*radio

def getArea(radio):
    return math.pi * math.pow(radio,2)

def redondear2decimales(numero):
    return round(numero,2)



